﻿Imports CompassCC.ProSolution.PSWebEnrolmentKit


Partial Class thankyou_failpayment
    Inherits webenrolmentcontrolvalidate


End Class
