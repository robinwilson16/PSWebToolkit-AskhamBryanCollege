Imports CompassCC.ProSolution.PSWebEnrolmentKit

Partial Class onlineenrolmentnotavailable_timeout
    Inherits webenrolmentcontrolvalidate

End Class
