﻿Imports CompassCC.ProSolution.PSWebEnrolmentKit

Partial Class webcontrols_thankyou_applications
    Inherits webenrolmentcontrolvalidate


    Protected Overrides Sub OnLoad(e As EventArgs)
        MyBase.OnLoad(e)



    End Sub


End Class
