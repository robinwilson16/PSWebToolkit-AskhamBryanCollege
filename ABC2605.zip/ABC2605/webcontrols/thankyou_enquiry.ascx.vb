﻿Imports CompassCC.ProSolution.PSWebEnrolmentKit


Partial Class thankyou_enquiry
    Inherits webenrolmentcontrolvalidate

   
End Class
