Imports CompassCC.ProSolution.PSWebEnrolmentKit

Partial Class onlineenrolmentnotavailable_euro
    Inherits webenrolmentcontrolvalidate


    Protected Overrides Sub OnLoad(e As EventArgs)
        MyBase.OnLoad(e)

        WorkingData.ShoppingCart.Items.Clear()

    End Sub
End Class
