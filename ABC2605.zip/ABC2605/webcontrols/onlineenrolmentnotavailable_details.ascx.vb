﻿Imports CompassCC.ProSolution.PSWebEnrolmentKit
Partial Class webcontrols_onlineenrolmentnotavailable_details
    Inherits webenrolmentcontrolvalidate

End Class
