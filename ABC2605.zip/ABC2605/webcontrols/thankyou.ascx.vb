Imports CompassCC.ProSolution.PSWebEnrolmentKit


Partial Class thankyou
    Inherits webenrolmentcontrolvalidate

    
End Class
