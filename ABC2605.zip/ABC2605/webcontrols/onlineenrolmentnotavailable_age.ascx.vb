Imports CompassCC.ProSolution.PSWebEnrolmentKit

Partial Class onlineenrolmentnotavailable_age
    Inherits webenrolmentcontrolvalidate

End Class
